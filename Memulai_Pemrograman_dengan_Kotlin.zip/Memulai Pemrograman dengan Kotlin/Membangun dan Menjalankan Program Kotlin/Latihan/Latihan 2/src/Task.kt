fun main() {
    println("Kotlin,\nis Awesome!")
}