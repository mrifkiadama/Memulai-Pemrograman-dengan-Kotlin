// main function
fun main() {
    val color : Color = Color.RED
    val color1 : Color = Color.GREEN
    val color2 : Color = Color.BLUE
    print(color)
    print(color1)
    print(color2)
}

enum class Color{
    RED, GREEN, BLUE
}