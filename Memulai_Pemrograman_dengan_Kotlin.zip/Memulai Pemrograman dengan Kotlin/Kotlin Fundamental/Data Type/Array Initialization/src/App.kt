// main function
fun main() {
    val intArray = intArrayOf(1, 3, 5, 7)
    print(intArray[2])
}